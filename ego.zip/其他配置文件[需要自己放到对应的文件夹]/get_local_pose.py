import rospy
from geometry_msgs.msg import PoseStamped, Vector3Stamped
import sys
from gazebo_msgs.msg import ModelStates
from nav_msgs.msg import Odometry

vehicle_type = sys.argv[1]
vehicle_num = int(sys.argv[2])
multi_pose_pub = [None] * vehicle_num
multi_speed_pub = [None] * vehicle_num
multi_local_pose = [PoseStamped() for i in range(vehicle_num)]
multi_speed = [Vector3Stamped() for i in range(vehicle_num)]
# TODO yjq add
multi_odom_pub = [None] * vehicle_num
multi_odom = [Odometry() for i in range(vehicle_num)]


# 无人机body坐标系到相机坐标系平移关系为(0.1,0,0)
def gazebo_model_state_callback(msg):
    for vehicle_id in range(vehicle_num):
        id = msg.name.index(vehicle_type + "_" + str(vehicle_id))
        multi_local_pose[vehicle_id].header.stamp = rospy.Time().now()
        multi_local_pose[vehicle_id].header.frame_id = "map"
        multi_local_pose[vehicle_id].pose = msg.pose[id]

        multi_speed[vehicle_id].header.stamp = rospy.Time().now()
        multi_speed[vehicle_id].header.frame_id = "map"
        multi_speed[vehicle_id].vector = msg.twist[id]

        multi_odom[vehicle_id].header.frame_id = "world"
        multi_odom[vehicle_id].child_frame_id = "world"

        multi_odom[vehicle_id].pose.pose.position.x = msg.pose[id].position.x
        multi_odom[vehicle_id].pose.pose.position.y = msg.pose[id].position.y
        multi_odom[vehicle_id].pose.pose.position.z = msg.pose[id].position.z
        multi_odom[vehicle_id].pose.pose.orientation.x = msg.pose[id].orientation.x
        multi_odom[vehicle_id].pose.pose.orientation.y = msg.pose[id].orientation.y
        multi_odom[vehicle_id].pose.pose.orientation.z = msg.pose[id].orientation.z
        multi_odom[vehicle_id].pose.pose.orientation.w = msg.pose[id].orientation.w
        multi_odom[vehicle_id].twist.twist.linear.x = msg.twist[id].linear.x
        multi_odom[vehicle_id].twist.twist.linear.y = msg.twist[id].linear.y
        multi_odom[vehicle_id].twist.twist.linear.z = msg.twist[id].linear.z


if __name__ == "__main__":
    rospy.init_node(vehicle_type + "_get_pose_groundtruth")
    gazebo_model_state_sub = rospy.Subscriber(
        "/gazebo/model_states", ModelStates, gazebo_model_state_callback, queue_size=1
    )
    for i in range(vehicle_num):
        # /mavros/ground_true/vision_pose/pose
        multi_pose_pub[i] = rospy.Publisher(
            vehicle_type + "_" + str(i) + "/mavros/vision_pose/pose",
            PoseStamped,
            queue_size=1,
        )
        multi_speed_pub[i] = rospy.Publisher(
            vehicle_type + "_" + str(i) + "/mavros/vision_speed/speed",
            Vector3Stamped,
            queue_size=1,
        )
        multi_odom_pub[i] = rospy.Publisher(
            vehicle_type + "_" + str(i) + "/odometry",
            Odometry,
            queue_size=1,
        )
        print("Get " + vehicle_type + "_" + str(i) + " groundtruth pose")
    rate = rospy.Rate(30)
    while not rospy.is_shutdown():
        for i in range(vehicle_num):
            multi_pose_pub[i].publish(multi_local_pose[i])
            multi_speed_pub[i].publish(multi_speed[i])
            multi_odom_pub[i].publish(multi_odom[i])
        try:
            rate.sleep()
        except:
            continue
